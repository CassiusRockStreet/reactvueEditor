import VerifyAuth from "./pages/VerifyAuth.vue";
import TinyMiceComponent from "./components/TinyMiceComponent.vue";
import noAuth from "./components/noAuth.vue";
import { createRouter, createWebHistory } from "vue-router";

// 2. Define some routes
// Each route should map to a component.
// We'll talk about nested routes later.
const routes = [
  { path: "/tiny-mce", component: TinyMiceComponent, name: "TinyMice" },
  { path: "/verify/:token", component: VerifyAuth, name: "Verify Token" },
  { path: "/unauthorized", component: noAuth, name: "Unauthorized" },
];
const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});
router.beforeEach((to) => {
  const token = localStorage.getItem("auth-token");
  if (to.path == "/tiny-mce") {
    if (token && token != "") {
      return true;
    } else {
      return { name: "Unauthorized" };
    }
  }
  return true;
});
export default router;
