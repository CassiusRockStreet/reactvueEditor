 <template>
   <div id="app">
     <editor
       api-key="g6l0o28whim46id5612moes6je2f7cwrlr7rolzkagfpz8mi"
       :init="init"
     />
   </div>
 </template>

 <script setup>
 import Editor from '@tinymce/tinymce-vue'
 </script>
