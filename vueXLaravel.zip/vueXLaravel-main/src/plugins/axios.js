// src/axios.js
import axios from 'axios';

const axiosInstance = axios.create({
  baseURL: 'https://test2.investoreports.com/api',
  // You can add other configuration settings here
});

export default axiosInstance;