<template>
    <div>
        <h2 v-if="!requestFinished">Authenticating...</h2>
        <h2 v-if="!authSuccess &&  requestFinished">Error: {{errorMessage}}</h2>
        <h2 v-if="authSuccess &&  requestFinished">You LoggedIn successfully: {{userInfo?.name}}</h2>
    </div>
</template>
<script setup>
    import axios from '@/plugins/axios';
    import { ref } from 'vue';
    import { useRoute, useRouter } from 'vue-router';

    const location = useRoute();
    const router = useRouter();
    const authSuccess = ref(false);
    const requestFinished = ref(false);
    const userInfo = ref({});
    const errorMessage = ref('');

    function verifyAuthToken(){
        axios.get(`/verify/${location.params.token}`).then((e)=>{
            userInfo.value = e.data.user_data
            requestFinished.value = true
            authSuccess.value = true
            localStorage.setItem('auth-token',location.params.token)
            router.push({name: 'TinyMice'})
        }).catch((e)=>{
            requestFinished.value = true
            errorMessage.value = e.response.data.message
            console.log(e)
        });
    }
    verifyAuthToken();
</script>