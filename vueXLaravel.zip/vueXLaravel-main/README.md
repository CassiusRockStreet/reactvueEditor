# vueXLaravel
# Installing package 

`npm i`

# Running the project

`npm run serve`



# Serve the Build
npm run build



